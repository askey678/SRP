﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApi.BAL.ViewModels
{
    public class RoleRegisterDto
    {
        public string RoleName { get; set; }


        public RoleRegisterDto() { }
    }
}
